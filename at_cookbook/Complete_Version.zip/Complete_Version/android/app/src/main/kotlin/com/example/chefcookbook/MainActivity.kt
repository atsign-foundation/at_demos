package com.example.chefcookbook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
